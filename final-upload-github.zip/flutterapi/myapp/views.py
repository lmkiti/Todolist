from django.shortcuts import render
from django.http import JsonResponse

from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from .serializers import TodolistSerializer
from .models import Todolist

# GET Data
@api_view(['GET'])
def all_todolist(request):
    alltodolist = Todolist.objects.all()
    serializer = TodolistSerializer(alltodolist,many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)


# POST DATA (save data to database)
@api_view(['POST'])
def post_todolist(request):
    if request.method == 'POST':
        serializer = TodolistSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)

@api_view(['PUT'])
def update_todolist(request,TID):
    # localhost:8000/api/update-todolist/TID
    todo = Todolist.objects.get(id=TID)

    if request.method == 'PUT':
        data = {}
        serializer = TodolistSerializer(todo,data=request.data)
        if serializer.is_valid():
            serializer.save()
            data['status'] = 'updated'
            return Response(data=data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)

@api_view(['DELETE'])
def delete_todolist(request,TID):
    todo = Todolist.objects.get(id=TID)

    if request.method == 'DELETE':
        delete = todo.delete()
        data = {}
        if delete:
            data['status'] = 'deleted'
            statuscode = status.HTTP_200_OK
        else:
            data['status'] = 'failed'
            statuscode = status.HTTP_400_BAD_REQUEST

        return Response(data=data, status=statuscode)





data = [
    {
        "title":"คอมพิวเตอร์คืออะไร?",
        "subtitle":"คอมพิวเตอร์ คือ อุปกรณืที่ใช้สำหรับคำนวณ",
        "image_url":"https://cdn.pixabay.com/photo/2016/11/19/15/32/laptop-1839876_960_720.jpg",
        "detail":"คอมพิวเตอร์ (อังกฤษ: computer) หรือศัพท์บัญญัติราชบัณฑิตยสภาว่า คณิตกรณ์[2][3] เป็นเครื่องจักรแบบสั่งการได้ที่ออกแบบมาเพื่อดำเนินการกับลำดับตัวดำเนินการทางตรรกศาสตร์หรือคณิตศาสตร์ โดยอนุกรมนี้อาจเปลี่ยนแปลงได้เมื่อพร้อม ส่งผลให้คอมพิวเตอร์สามารถแก้ปัญหาได้มากมาย/n/nคอมพิวเตอร์ถูกประดิษฐ์ออกมาให้ประกอบไปด้วยความจำรูปแบบต่าง ๆ เพื่อเก็บข้อมูล อย่างน้อยหนึ่งส่วนที่มีหน้าที่ดำเนินการคำนวณเกี่ยวกับตัวดำเนินการทางตรรกศาสตร์ และตัวดำเนินการทางคณิตศาสตร์ และส่วนควบคุมที่ใช้เปลี่ยนแปลงลำดับของตัวดำเนินการโดยยึดสารสนเทศที่ถูกเก็บไว้เป็นหลัก อุปกรณ์เหล่านี้จะยอมให้นำเข้าข้อมูลจากแหล่งภายนอก และส่งผลจากการคำนวณตัวดำเนินการออกไป"
    },
    {
        "title":"Flutter คือ?",
        "subtitle":"Tools สำหรับเขียนโปรแกรม",
        "image_url":"https://cdn.pixabay.com/photo/2016/11/19/15/32/laptop-1839876_960_720.jpg",
        "detail":"Flutter คือ Cross-Platform Framework ที่ใช้ในการพัฒนา Native Mobile Application (Android/iOS) พัฒนาโดยบริษัท Google Inc. โดยใช้ภาษา Dart ในการพัฒนา ที่มีความคล้ายกับภาษา C# และ Java"
    },
    {
        "title":"Pythone คือ?",
        "subtitle":"Program สำหรับเขียน Application",
        "image_url":"https://cdn.pixabay.com/photo/2016/11/19/15/32/laptop-1839876_960_720.jpg",
        "detail":"โลกในยุคดิจิทัล (Digital age) ได้มีความก้าวหน้าในการพัฒนาเทคโนโลยีอย่างรวดเร็วแบบก้าวกระโดด ทำให้มีบทบาทสำคัญในการพัฒนาขับเคลื่อนธุรกิจ และอำนวยความสะดวกในชีวิตประจำวัน เช่น การทำธุรกรรมทางการเงินกับธนาคารแบบออนไลน์ การใช้ระบบสั่งการคอมพิวเตอร์ด้วยเสียง การตรวจสุขภาพเบื้องต้นด้วยแอปพลิเคชันบนมือถือ และระบบ Google Search ที่สามารถรู้ว่าคุณกำลังค้นหาข้อมูลอะไรก่อนที่เราจะพิมพ์จบประโยค เป็นต้น นอกจากนั้นยังมีนวัตกรรมเทคโนโลยีที่มีความล้ำหน้าต่าง ๆ โดยเฉพาะงานทางด้านปัญญาประดิษฐ์ (Artificial Intelligence) เช่น บริษัท DeepMind ได้พัฒนาระบบคอมพิวเตอร์ Alpha Go ที่สามารถแข่งขันเอาชนะเกมหมากล้อมเหนือแชมป์โลกได้ และยังมีระบบคอมพิวเตอร์ล่าสุดที่ชื่อว่า AlphaStar  ที่สามารถเอาชนะทีมมนุษย์ในเกม StarCraft II ได้ รวมถึงรถยนต์ไร้คนขับที่สามารถเดินทางบนถนนได้จริง และหุ่นยนต์คอมพิวเตอร์ที่จะสามารถทำงานทดแทนมนุษย์ได้ในอนาคต"
    },
    {
        "title":"Dart คือ?",
        "subtitle":"Program สำหรับเขียน Application",
        "image_url":"https://cdn.pixabay.com/photo/2016/11/19/15/32/laptop-1839876_960_720.jpg",
        "detail":"โลกในยุคดิจิทัล (Digital age) ได้มีความก้าวหน้าในการพัฒนาเทคโนโลยีอย่างรวดเร็วแบบก้าวกระโดด ทำให้มีบทบาทสำคัญในการพัฒนาขับเคลื่อนธุรกิจ และอำนวยความสะดวกในชีวิตประจำวัน เช่น การทำธุรกรรมทางการเงินกับธนาคารแบบออนไลน์ การใช้ระบบสั่งการคอมพิวเตอร์ด้วยเสียง การตรวจสุขภาพเบื้องต้นด้วยแอปพลิเคชันบนมือถือ และระบบ Google Search ที่สามารถรู้ว่าคุณกำลังค้นหาข้อมูลอะไรก่อนที่เราจะพิมพ์จบประโยค เป็นต้น นอกจากนั้นยังมีนวัตกรรมเทคโนโลยีที่มีความล้ำหน้าต่าง ๆ โดยเฉพาะงานทางด้านปัญญาประดิษฐ์ (Artificial Intelligence) เช่น บริษัท DeepMind ได้พัฒนาระบบคอมพิวเตอร์ Alpha Go ที่สามารถแข่งขันเอาชนะเกมหมากล้อมเหนือแชมป์โลกได้ และยังมีระบบคอมพิวเตอร์ล่าสุดที่ชื่อว่า AlphaStar  ที่สามารถเอาชนะทีมมนุษย์ในเกม StarCraft II ได้ รวมถึงรถยนต์ไร้คนขับที่สามารถเดินทางบนถนนได้จริง และหุ่นยนต์คอมพิวเตอร์ที่จะสามารถทำงานทดแทนมนุษย์ได้ในอนาคต"
    }
]



def Home(request):
    return JsonResponse(data=data,safe=False,json_dumps_params={'ensure_ascii':False})


